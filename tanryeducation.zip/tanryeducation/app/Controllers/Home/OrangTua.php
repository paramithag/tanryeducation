<?php

namespace App\Controllers\Home;

use App\Controllers\BaseController;

class OrangTua extends BaseController
{
    public function index()
    {
        return view('home/orangtua');
    }
}
