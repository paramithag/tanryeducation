<?php

namespace App\Controllers\Auth;

use App\Controllers\BaseController;
use App\Models\UsersModel;

class Auth extends BaseController
{
    public function index()
    {
        return view('auth/login');
    }

    public function process()
    {
        session()->setFlashdata('error', $this->validator->listErrors());
        return redirect()->back()->withInput();
        $users = new UsersModel();
        $users->insert([
            'password' => password_hash($this->request->getVar('password'), PASSWORD_BCRYPT),
            'email' => $this->request->getVar('email')
        ]);
        return redirect()->to('/login');
    }
}
