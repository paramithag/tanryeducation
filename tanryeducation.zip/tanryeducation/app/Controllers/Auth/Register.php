<?php

namespace App\Controllers\Auth;

use App\Controllers\BaseController;
use App\Models\UsersModel;

class Register extends BaseController
{
    public function index()
    {
        return view('auth/register');
    }

    public function process()
    {
        session()->setFlashdata('error', $this->validator->listErrors());
        return redirect()->back()->withInput();
        $users = new UsersModel();
        $users->insert([
            'id_user' => $this->request->getVar('id_user'),
            'password' => password_hash($this->request->getVar('password'), PASSWORD_BCRYPT),
            'name' => $this->request->getVar('name'),
            'email' => $this->request->getVar('email')
        ]);
        return redirect()->to('/login');
    }
}
