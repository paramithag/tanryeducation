<?php

namespace App\Controllers\Progress;

use App\Controllers\BaseController;

class OrangTua extends BaseController
{
    public function index()
    {
        return view('progress/orangtua');
    }
}
