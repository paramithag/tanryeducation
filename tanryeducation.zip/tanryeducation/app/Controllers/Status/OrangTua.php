<?php

namespace App\Controllers\Status;

use App\Controllers\BaseController;

class OrangTua extends BaseController
{
    public function index()
    {
        return view('status/orangtua');
    }
}
